# This is a blank script for you to practice
