# Name:  Last, First
# netID: Insert your netID here

# I worked with the following classmates on this assignment:
# 1) Name: Last, First
# 2) Name: Last, First

######################################################################
# Place your solutions below here
######################################################################

# Note: For each of the functions in this assignment, you will need to write a
# test function AND the function itself. I strongly recommend you
# write the test function *FIRST*, and then write the function.
# Your test functions will count for half of the available credit for each
# problem. Think carefully about the test cases to include in your test
# functions.

isPositiveMultipleOf4Or7 <- function(n) {
  return(42)
}

isEvenPositiveInt <- function(x) {
  return(42)
}

isLeapYear <- function(year) {
  return(42)
}

getTheCents <- function(n) {
  return(42)
}

isNumericLooking <- function(n) {
  return(42)
}

#--------------------------------------------------------------
# ignore_rest
# This comment is for the autograder - it will ignore all code below here

#--------------------------------------------------------------
# Test cases:

test_isPositiveMultipleOf4Or7 <- function() {
    cat("Testing isPositiveMultipleOf4Or7()...")
    # Write test cases here
    cat("Passed!\n")
}

test_isEvenPositiveInt <- function() {
    cat("Testing isEvenPositiveInt()...")
    # Write test cases here
    cat("Passed!\n")
}

test_isLeapYear <- function() {
    cat("Testing isLeapYear()...")
    # Write test cases here
    cat("Passed!\n")
}

test_getTheCents <- function() {
    cat("Testing getTheCents()...")
    # Write test cases here
    cat("Passed!\n")
}

test_isNumericLooking <- function() {
    cat("Testing isNumericLooking()...")
    # Write test cases here
    cat("Passed!\n")
}

test_all <- function() {
    cat("Testing all functions...\n")
    test_isPositiveMultipleOf4Or7()
    test_isEvenPositiveInt()
    test_isLeapYear()
    test_getTheCents()
    test_isNumericLooking()
    cat("All passed!\n")
}

# Run this to run all tests
test_all()

#--------------------------------------------------------------
# Reflection: